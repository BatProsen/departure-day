# Add project specific ProGuard rules here.
# This file is intentionally minimal since minifyEnabled is false for this prototype.

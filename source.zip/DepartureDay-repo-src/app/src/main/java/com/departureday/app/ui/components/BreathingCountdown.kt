package com.departureday.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.departureday.app.ui.theme.Cream
import com.departureday.app.ui.theme.DisplaySerif
import com.departureday.app.ui.theme.Ink
import com.departureday.app.ui.theme.Sage
import com.departureday.app.ui.theme.SageDeep
import com.departureday.app.ui.theme.SlateLight

@Composable
fun BreathingCountdown(hours: Int, minutes: Int) {
    val transition = rememberInfiniteTransition(label = "breathe")
    val outerScale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "outerScale"
    )
    val innerScale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.14f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "innerScale"
    )

    Box(
        modifier = Modifier.size(220.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .scale(innerScale)
                .border(width = 1.dp, color = Sage.copy(alpha = 0.5f), shape = CircleShape)
        )
        Box(
            modifier = Modifier
                .size(184.dp)
                .scale(outerScale)
                .border(width = 1.5.dp, color = SageDeep.copy(alpha = 0.8f), shape = CircleShape)
        )
        Box(
            modifier = Modifier
                .size(154.dp)
                .background(Cream, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "DEPARTS IN",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SlateLight,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "${hours}h ${minutes}m",
                    fontFamily = DisplaySerif,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Ink
                )
            }
        }
    }
}

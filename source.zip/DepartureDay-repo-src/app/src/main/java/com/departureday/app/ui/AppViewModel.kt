package com.departureday.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.departureday.app.data.MockBackend
import com.departureday.app.data.PaymentResult
import com.departureday.app.data.model.Booking
import com.departureday.app.data.model.ChecklistItem
import com.departureday.app.data.model.PaymentMethod
import com.departureday.app.data.model.ServiceOffering
import com.departureday.app.data.model.Trip
import kotlinx.coroutines.launch

/** Where the booking sheet currently is in its flow. */
sealed class BookingStep {
    data object Details : BookingStep()
    data object Processing : BookingStep()
    data object Success : BookingStep()
    data class Failed(val message: String) : BookingStep()
}

class AppViewModel : ViewModel() {

    private val backend = MockBackend()

    val trip: Trip = backend.currentTrip

    var checklist by mutableStateOf(backend.initialChecklist())
        private set

    var bookings by mutableStateOf<List<Booking>>(emptyList())
        private set

    // --- Booking sheet state -------------------------------------------------
    var activeService by mutableStateOf<ServiceOffering?>(null)
        private set

    var bookingStep by mutableStateOf<BookingStep>(BookingStep.Details)
        private set

    var bookingNote by mutableStateOf("")

    var selectedPaymentMethod by mutableStateOf(PaymentMethod.UPI)

    var toastMessage by mutableStateOf<String?>(null)
        private set

    fun toggleChecklistItem(id: String) {
        checklist = checklist.map { if (it.id == id) it.copy(done = !it.done) else it }
    }

    fun startBooking(service: ServiceOffering) {
        activeService = service
        bookingStep = BookingStep.Details
        bookingNote = ""
        selectedPaymentMethod = PaymentMethod.UPI
    }

    fun closeBookingSheet() {
        activeService = null
        bookingStep = BookingStep.Details
    }

    /** Submits the mock payment, then creates the booking on success. */
    fun submitPayment(cardOrUpiInputValid: Boolean) {
        val service = activeService ?: return
        if (!cardOrUpiInputValid) {
            bookingStep = BookingStep.Failed("Check your payment details and try again.")
            return
        }
        bookingStep = BookingStep.Processing
        viewModelScope.launch {
            when (val result = backend.processPayment(service, selectedPaymentMethod)) {
                is PaymentResult.Success -> {
                    val booking = backend.createBooking(
                        service = service,
                        tripId = trip.id,
                        note = bookingNote,
                        paymentMethod = selectedPaymentMethod,
                        amountPaid = service.basePrice
                    )
                    bookings = bookings + booking
                    markServiceBookedOnChecklist(service.id)
                    bookingStep = BookingStep.Success
                }
                is PaymentResult.Failure -> {
                    bookingStep = BookingStep.Failed(result.reason)
                }
            }
        }
    }

    fun finishBookingFlow() {
        val service = activeService
        closeBookingSheet()
        if (service != null) {
            showToast("${service.name} booked and paid")
        }
    }

    private fun markServiceBookedOnChecklist(serviceId: String) {
        val alreadyOnChecklist = checklist.any { it.serviceId == serviceId }
        checklist = if (alreadyOnChecklist) {
            checklist.map {
                if (it.serviceId == serviceId) {
                    it.copy(done = true, sub = "Booked & paid")
                } else it
            }
        } else {
            val service = activeService
            checklist + ChecklistItem(
                id = serviceId,
                label = service?.name ?: "Service booked",
                sub = "Booked & paid",
                done = true,
                bookable = false,
                serviceId = serviceId
            )
        }
    }

    private fun showToast(message: String) {
        toastMessage = message
    }

    fun clearToast() {
        toastMessage = null
    }
}

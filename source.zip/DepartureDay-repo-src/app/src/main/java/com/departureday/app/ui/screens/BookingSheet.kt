package com.departureday.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.departureday.app.data.model.PaymentMethod
import com.departureday.app.data.model.ServiceOffering
import com.departureday.app.ui.BookingStep
import com.departureday.app.ui.theme.*

@Composable
fun BookingSheet(
    service: ServiceOffering,
    step: BookingStep,
    note: String,
    onNoteChange: (String) -> Unit,
    paymentMethod: PaymentMethod,
    onPaymentMethodChange: (PaymentMethod) -> Unit,
    onClose: () -> Unit,
    onSubmitPayment: (Boolean) -> Unit,
    onFinish: () -> Unit,
    tripSummary: String
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(androidx.compose.ui.graphics.Color(0x731F1C16))
            .clickable(
                indication = null,
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
            ) { if (step !is BookingStep.Processing) onClose() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 680.dp)
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Paper)
                .clickable(
                    indication = null,
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                ) { /* swallow clicks so they don't dismiss */ }
                .padding(horizontal = 22.dp, vertical = 10.dp)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 24.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(38.dp)
                    .height(4.dp)
                    .align(Alignment.CenterHorizontally)
                    .clip(RoundedCornerShape(4.dp))
                    .background(LineColor)
                    .padding(bottom = 16.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))

            AnimatedContent(targetState = step, label = "bookingStep") { currentStep ->
                when (currentStep) {
                    is BookingStep.Details -> DetailsStep(
                        service = service,
                        note = note,
                        onNoteChange = onNoteChange,
                        paymentMethod = paymentMethod,
                        onPaymentMethodChange = onPaymentMethodChange,
                        tripSummary = tripSummary,
                        onClose = onClose,
                        onProceed = { valid -> onSubmitPayment(valid) }
                    )
                    is BookingStep.Processing -> ProcessingStep(service = service)
                    is BookingStep.Success -> SuccessStep(service = service, onFinish = onFinish)
                    is BookingStep.Failed -> FailedStep(message = currentStep.message, onRetry = { onSubmitPayment(true) }, onClose = onClose)
                }
            }
        }
    }
}

@Composable
private fun DetailsStep(
    service: ServiceOffering,
    note: String,
    onNoteChange: (String) -> Unit,
    paymentMethod: PaymentMethod,
    onPaymentMethodChange: (PaymentMethod) -> Unit,
    tripSummary: String,
    onClose: () -> Unit,
    onProceed: (Boolean) -> Unit
) {
    var upiId by remember { mutableStateOf("") }
    var cardNumber by remember { mutableStateOf("") }
    var cardExpiry by remember { mutableStateOf("") }
    var cardCvv by remember { mutableStateOf("") }

    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(PaperDeep),
                contentAlignment = Alignment.Center
            ) {
                Icon(service.icon, contentDescription = null, tint = InkSoft, modifier = Modifier.size(18.dp))
            }
            Text(
                service.name,
                fontFamily = DisplaySerif,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = Ink,
                modifier = Modifier.padding(start = 10.dp)
            )
        }
        Text(service.description, fontSize = 13.sp, color = Slate, modifier = Modifier.padding(top = 10.dp, bottom = 16.dp))

        SectionLabel("FOR THIS TRIP")
        InfoBox(tripSummary)

        SectionLabel("ANYTHING WE SHOULD KNOW? (OPTIONAL)", topPadding = 14)
        OutlinedTextField(
            value = note,
            onValueChange = onNoteChange,
            placeholder = { Text("e.g. travelling with my elderly mother, she uses a walking stick", fontSize = 12.5.sp) },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 64.dp),
            colors = fieldColors(),
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp)
        )

        SectionLabel("PAY WITH", topPadding = 18)
        Row(modifier = Modifier.fillMaxWidth()) {
            PaymentMethodTab(
                label = "UPI",
                icon = Icons.Filled.AccountBalanceWallet,
                selected = paymentMethod == PaymentMethod.UPI,
                onClick = { onPaymentMethodChange(PaymentMethod.UPI) },
                modifier = Modifier.weight(1f).padding(end = 6.dp)
            )
            PaymentMethodTab(
                label = "Card",
                icon = Icons.Filled.CreditCard,
                selected = paymentMethod == PaymentMethod.CARD,
                onClick = { onPaymentMethodChange(PaymentMethod.CARD) },
                modifier = Modifier.weight(1f).padding(start = 6.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (paymentMethod == PaymentMethod.UPI) {
            OutlinedTextField(
                value = upiId,
                onValueChange = { upiId = it },
                label = { Text("UPI ID", fontSize = 12.sp) },
                placeholder = { Text("yourname@upi", fontSize = 12.5.sp) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = fieldColors()
            )
        } else {
            OutlinedTextField(
                value = cardNumber,
                onValueChange = { if (it.length <= 16) cardNumber = it.filter { c -> c.isDigit() } },
                label = { Text("Card number", fontSize = 12.sp) },
                placeholder = { Text("1234 5678 9012 3456", fontSize = 12.5.sp) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = fieldColors()
            )
            Row(modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
                OutlinedTextField(
                    value = cardExpiry,
                    onValueChange = { if (it.length <= 5) cardExpiry = it },
                    label = { Text("MM/YY", fontSize = 12.sp) },
                    placeholder = { Text("08/29", fontSize = 12.5.sp) },
                    modifier = Modifier.weight(1f).padding(end = 6.dp),
                    singleLine = true,
                    colors = fieldColors()
                )
                OutlinedTextField(
                    value = cardCvv,
                    onValueChange = { if (it.length <= 3) cardCvv = it.filter { c -> c.isDigit() } },
                    label = { Text("CVV", fontSize = 12.sp) },
                    placeholder = { Text("123", fontSize = 12.5.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = VisualTransformation.None,
                    modifier = Modifier.weight(1f).padding(start = 6.dp),
                    singleLine = true,
                    colors = fieldColors()
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(PaperDeep)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Total", fontSize = 13.5.sp, color = Slate, fontWeight = FontWeight.SemiBold)
            Text("₹${service.basePrice}", fontSize = 16.sp, color = Ink, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row {
            BigButton(
                text = "Cancel",
                modifier = Modifier.weight(1f),
                background = Cream,
                textColor = Slate,
                border = LineColor,
                onClick = onClose
            )
            Spacer(modifier = Modifier.width(10.dp))
            BigButton(
                text = "Pay ₹${service.basePrice}",
                modifier = Modifier.weight(2f),
                background = Coral,
                textColor = Cream,
                onClick = {
                    val valid = if (paymentMethod == PaymentMethod.UPI) {
                        upiId.contains("@") && upiId.length > 4
                    } else {
                        cardNumber.length >= 12 && cardExpiry.length == 5 && cardCvv.length == 3
                    }
                    onProceed(valid)
                }
            )
        }
        Text(
            if (paymentMethod == PaymentMethod.CARD)
                "This is a mock payment screen for demo purposes — no real card data is sent anywhere."
            else
                "This is a mock payment screen for demo purposes — no real UPI transaction occurs.",
            fontSize = 10.5.sp,
            color = SlateLight,
            modifier = Modifier.padding(top = 10.dp)
        )
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    unfocusedContainerColor = Cream,
    focusedContainerColor = Cream,
    unfocusedBorderColor = LineColor,
    focusedBorderColor = Coral
)

@Composable
private fun PaymentMethodTab(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) CoralPale else Cream)
            .border(1.dp, if (selected) Coral else LineColor, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (selected) Coral else Slate, modifier = Modifier.size(16.dp))
        Text(
            label,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (selected) Coral else Slate,
            modifier = Modifier.padding(start = 7.dp)
        )
    }
}

@Composable
private fun SectionLabel(text: String, topPadding: Int = 0) {
    Text(
        text,
        fontSize = 12.5.sp,
        fontWeight = FontWeight.Bold,
        color = Ink,
        modifier = Modifier.padding(top = topPadding.dp, bottom = 6.dp)
    )
}

@Composable
private fun InfoBox(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Cream)
            .border(1.dp, LineColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 13.dp, vertical = 11.dp)
    ) {
        Text(text, fontSize = 13.5.sp, color = Ink)
    }
}

@Composable
private fun BigButton(
    text: String,
    modifier: Modifier = Modifier,
    background: androidx.compose.ui.graphics.Color,
    textColor: androidx.compose.ui.graphics.Color,
    border: androidx.compose.ui.graphics.Color? = null,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(background)
            .let { if (border != null) it.border(1.dp, border, RoundedCornerShape(12.dp)) else it }
            .clickable { onClick() }
            .padding(vertical = 13.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = textColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
private fun ProcessingStep(service: ServiceOffering) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 50.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(color = Coral, strokeWidth = 3.dp, modifier = Modifier.size(46.dp))
        Text(
            "Processing payment…",
            fontFamily = DisplaySerif,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = Ink,
            modifier = Modifier.padding(top = 20.dp)
        )
        Text(
            "Confirming ₹${service.basePrice} for ${service.name.lowercase()}",
            fontSize = 12.5.sp,
            color = SlateLight,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun SuccessStep(service: ServiceOffering, onFinish: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(Sage),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Check, contentDescription = null, tint = Cream, modifier = Modifier.size(30.dp))
        }
        Text(
            "Payment successful",
            fontFamily = DisplaySerif,
            fontSize = 19.sp,
            fontWeight = FontWeight.SemiBold,
            color = Ink,
            modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)
        )
        Text(
            "₹${service.basePrice} paid · ${service.name} is booked and added to your trip checklist.",
            fontSize = 13.5.sp,
            color = Slate,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(horizontal = 12.dp, bottom = 22.dp)
        )
        BigButton(
            text = "Back to my trip",
            modifier = Modifier.fillMaxWidth(),
            background = Ink,
            textColor = Paper,
            onClick = onFinish
        )
    }
}

@Composable
private fun FailedStep(message: String, onRetry: () -> Unit, onClose: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(CoralPale),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Error, contentDescription = null, tint = CoralDeep, modifier = Modifier.size(30.dp))
        }
        Text(
            "Payment couldn't go through",
            fontFamily = DisplaySerif,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            color = Ink,
            modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)
        )
        Text(
            message,
            fontSize = 13.5.sp,
            color = Slate,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(horizontal = 12.dp, bottom = 22.dp)
        )
        Row(modifier = Modifier.fillMaxWidth()) {
            BigButton(text = "Close", modifier = Modifier.weight(1f), background = Cream, textColor = Slate, border = LineColor, onClick = onClose)
            Spacer(modifier = Modifier.width(10.dp))
            BigButton(text = "Try again", modifier = Modifier.weight(1f), background = Coral, textColor = Cream, onClick = onRetry)
        }
    }
}

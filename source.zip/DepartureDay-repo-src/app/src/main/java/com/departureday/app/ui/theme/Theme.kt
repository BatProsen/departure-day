package com.departureday.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DepartureDayColorScheme = lightColorScheme(
    primary = Coral,
    onPrimary = Cream,
    primaryContainer = CoralPale,
    secondary = Sage,
    onSecondary = Cream,
    background = Paper,
    onBackground = Ink,
    surface = Cream,
    onSurface = Ink,
    surfaceVariant = PaperDeep,
    onSurfaceVariant = Slate,
    outline = LineColor,
    error = CoralDeep
)

@Composable
fun DepartureDayTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DepartureDayColorScheme,
        typography = AppTypography,
        content = content
    )
}

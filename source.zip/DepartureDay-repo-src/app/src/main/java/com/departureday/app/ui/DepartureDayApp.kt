package com.departureday.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.departureday.app.data.model.ServiceCatalog
import com.departureday.app.ui.components.AppTab
import com.departureday.app.ui.components.BottomNav
import com.departureday.app.ui.screens.BookingSheet
import com.departureday.app.ui.screens.CalmScreen
import com.departureday.app.ui.screens.HomeScreen
import com.departureday.app.ui.screens.ProfileScreen
import com.departureday.app.ui.screens.ServicesScreen
import com.departureday.app.ui.theme.Ink
import com.departureday.app.ui.theme.Paper
import kotlinx.coroutines.delay

@Composable
fun DepartureDayApp(viewModel: AppViewModel = viewModel()) {
    var activeTab by remember { mutableStateOf(AppTab.HOME) }

    Scaffold(
        containerColor = Paper,
        bottomBar = { BottomNav(active = activeTab, onChange = { activeTab = it }) }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (activeTab) {
                AppTab.HOME -> HomeScreen(
                    trip = viewModel.trip,
                    checklist = viewModel.checklist,
                    onToggle = viewModel::toggleChecklistItem,
                    onBookItem = { serviceId ->
                        ServiceCatalog.all.find { it.id == serviceId }?.let { viewModel.startBooking(it) }
                    },
                    onOpenServices = { activeTab = AppTab.SERVICES }
                )
                AppTab.SERVICES -> ServicesScreen(
                    services = ServiceCatalog.all,
                    onBook = { viewModel.startBooking(it) }
                )
                AppTab.CALM -> CalmScreen()
                AppTab.PROFILE -> ProfileScreen(bookings = viewModel.bookings)
            }

            val service = viewModel.activeService
            AnimatedVisibility(
                visible = service != null,
                enter = fadeIn() + slideInVertically(initialOffsetY = { it / 4 }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 4 })
            ) {
                service?.let {
                    BookingSheet(
                        service = it,
                        step = viewModel.bookingStep,
                        note = viewModel.bookingNote,
                        onNoteChange = { n -> viewModel.bookingNote = n },
                        paymentMethod = viewModel.selectedPaymentMethod,
                        onPaymentMethodChange = { m -> viewModel.selectedPaymentMethod = m },
                        onClose = viewModel::closeBookingSheet,
                        onSubmitPayment = viewModel::submitPayment,
                        onFinish = {
                            viewModel.finishBookingFlow()
                            activeTab = AppTab.HOME
                        },
                        tripSummary = "${viewModel.trip.route.split(" → ").firstOrNull() ?: ""} · ${viewModel.trip.departureLabel}"
                    )
                }
            }

            ToastHost(
                message = viewModel.toastMessage,
                onConsumed = viewModel::clearToast,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}

@Composable
private fun ToastHost(message: String?, onConsumed: () -> Unit, modifier: Modifier = Modifier) {
    LaunchedEffect(message) {
        if (message != null) {
            delay(2600)
            onConsumed()
        }
    }
    AnimatedVisibility(
        visible = message != null,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 90.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Ink)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = message ?: "",
                color = Paper,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
            )
        }
    }
}

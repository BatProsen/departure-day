package com.departureday.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.departureday.app.data.model.ServiceOffering
import com.departureday.app.ui.theme.*

@Composable
fun ServicesScreen(
    services: List<ServiceOffering>,
    onBook: (ServiceOffering) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        item {
            Text(
                "For your trip to Kolkata Station",
                fontSize = 12.5.sp,
                color = SlateLight,
                modifier = Modifier.padding(top = 14.dp, bottom = 2.dp)
            )
            Text(
                "Services you can book",
                fontFamily = DisplaySerif,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = Ink,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }
        items(services, key = { it.id }) { service ->
            ServiceCard(service = service, onBook = { onBook(service) })
        }
    }
}

@Composable
private fun ServiceCard(service: ServiceOffering, onBook: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, LineColor, RoundedCornerShape(16.dp))
            .background(Cream)
            .padding(16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(PaperDeep),
            contentAlignment = Alignment.Center
        ) {
            Icon(service.icon, contentDescription = null, tint = InkSoft, modifier = Modifier.size(20.dp))
        }
        Column(modifier = Modifier.padding(start = 13.dp).weight(1f)) {
            Text(service.name, fontSize = 14.5.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(
                service.description,
                fontSize = 12.5.sp,
                color = Slate,
                modifier = androidx.compose.ui.Modifier.padding(top = 3.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Schedule, contentDescription = null, tint = SlateLight, modifier = Modifier.size(12.dp))
                    Text(
                        service.durationLabel,
                        fontSize = 11.5.sp,
                        color = SlateLight,
                        modifier = Modifier.padding(start = 4.dp)
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "₹${service.basePrice}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Ink,
                        modifier = Modifier.padding(end = 10.dp)
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(9.dp))
                            .background(Coral)
                            .clickable { onBook() }
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    ) {
                        Text("Book", color = Cream, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

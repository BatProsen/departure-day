package com.departureday.app.data

import com.departureday.app.data.model.Booking
import com.departureday.app.data.model.BookingStatus
import com.departureday.app.data.model.ChecklistItem
import com.departureday.app.data.model.PaymentMethod
import com.departureday.app.data.model.ServiceOffering
import com.departureday.app.data.model.Trip
import com.departureday.app.data.model.TravelMode
import kotlinx.coroutines.delay
import java.util.UUID

/**
 * Stands in for a real backend + payment gateway.
 *
 * Replace the bodies of these functions with real network calls (Retrofit/Ktor)
 * and a real payment SDK (Razorpay/PayU/Stripe) when you're ready to go live.
 * The function signatures are written so the rest of the app won't need to change.
 */
class MockBackend {

    val currentTrip = Trip(
        id = "trip-1",
        title = "Trip to Kolkata",
        route = "Howrah Jn → Kolkata Station",
        mode = TravelMode.TRAIN,
        departureLabel = "Tomorrow, 6:40 AM · Seat 34, Coach B2",
        hoursLeft = 18,
        minutesLeft = 24
    )

    fun initialChecklist(): List<ChecklistItem> = listOf(
        ChecklistItem("ticket", "Ticket confirmed", "PNR verified, seat 34, B2", done = true),
        ChecklistItem("packing", "Packing assistance", "Not booked yet", done = false, bookable = true, serviceId = "packing"),
        ChecklistItem("cab", "Cab to station", "Not booked yet", done = false, bookable = true, serviceId = "cab"),
        ChecklistItem("documents", "ID & documents ready", "Aadhaar, ticket copy", done = false),
        ChecklistItem("weather", "Checked weather at destination", "27°C, clear", done = true)
    )

    /**
     * Simulates submitting card/UPI details to a payment gateway and waiting for
     * authorization. Always succeeds after a short delay, matching the "fake
     * payment screen that always succeeds" requirement.
     */
    suspend fun processPayment(
        service: ServiceOffering,
        method: PaymentMethod
    ): PaymentResult {
        delay(1600) // simulate network + gateway round trip
        return PaymentResult.Success(
            transactionId = "PAY-${UUID.randomUUID().toString().take(8).uppercase()}"
        )
    }

    suspend fun createBooking(
        service: ServiceOffering,
        tripId: String,
        note: String,
        paymentMethod: PaymentMethod,
        amountPaid: Int
    ): Booking {
        delay(300) // simulate writing the booking record
        return Booking(
            id = UUID.randomUUID().toString(),
            service = service,
            tripId = tripId,
            note = note,
            paymentMethod = paymentMethod,
            amountPaid = amountPaid,
            status = BookingStatus.CONFIRMED,
            bookedAtLabel = "Just now",
            referenceCode = "DD-${(1000..9999).random()}"
        )
    }
}

sealed class PaymentResult {
    data class Success(val transactionId: String) : PaymentResult()
    data class Failure(val reason: String) : PaymentResult()
}

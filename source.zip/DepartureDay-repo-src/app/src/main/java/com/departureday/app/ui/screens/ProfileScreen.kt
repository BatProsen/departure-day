package com.departureday.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.departureday.app.data.model.Booking
import com.departureday.app.data.model.PaymentMethod
import com.departureday.app.ui.theme.*

@Composable
fun ProfileScreen(bookings: List<Booking>) {
    LazyColumn(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        item {
            Text(
                "You",
                fontFamily = DisplaySerif,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = Ink,
                modifier = Modifier.padding(top = 18.dp, bottom = 16.dp)
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Cream)
                    .border(1.dp, LineColor, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Text("Prosen", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Ink)
                Text("Kolkata · 2 saved travellers", fontSize = 12.5.sp, color = SlateLight)
            }
        }

        item {
            Text(
                "SAVED TRAVELLERS",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Ink,
                modifier = Modifier.padding(top = 20.dp, bottom = 10.dp)
            )
        }
        item {
            TravellerRow("Mother — uses a walking stick, prefers lower berth")
        }
        item {
            TravellerRow("Self", modifier = Modifier.padding(top = 9.dp))
        }

        item {
            Text(
                "YOUR BOOKINGS",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Ink,
                modifier = Modifier.padding(top = 22.dp, bottom = 10.dp)
            )
        }

        if (bookings.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Cream)
                        .border(1.dp, LineColor, RoundedCornerShape(14.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        "Nothing booked yet. Services you pay for will appear here with a receipt.",
                        fontSize = 13.sp,
                        color = SlateLight
                    )
                }
            }
        } else {
            items(bookings.reversed(), key = { it.id }) { booking ->
                BookingReceiptCard(booking, modifier = Modifier.padding(bottom = 10.dp))
            }
        }

        item { Box(modifier = Modifier.padding(bottom = 16.dp)) }
    }
}

@Composable
private fun TravellerRow(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Cream)
            .border(1.dp, LineColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(text, fontSize = 13.sp, color = Ink)
    }
}

@Composable
private fun BookingReceiptCard(booking: Booking, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Cream)
            .border(1.dp, LineColor, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Sage),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Check, contentDescription = null, tint = Cream, modifier = Modifier.size(16.dp))
        }
        Column(modifier = Modifier.padding(start = 12.dp).weight(1f)) {
            Text(booking.service.name, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = Ink)
            Text(
                "Paid via ${if (booking.paymentMethod == PaymentMethod.UPI) "UPI" else "Card"} · ${booking.bookedAtLabel}",
                fontSize = 11.5.sp,
                color = SlateLight,
                modifier = Modifier.padding(top = 2.dp)
            )
            Text(
                "Ref: ${booking.referenceCode}",
                fontSize = 11.sp,
                color = SlateLight,
                modifier = Modifier.padding(top = 1.dp)
            )
        }
        Text("₹${booking.amountPaid}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Ink)
    }
}

package com.departureday.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.departureday.app.data.model.ChecklistItem
import com.departureday.app.data.model.Trip
import com.departureday.app.data.model.icon
import com.departureday.app.ui.components.BreathingCountdown
import com.departureday.app.ui.theme.*

@Composable
fun HomeScreen(
    trip: Trip,
    checklist: List<ChecklistItem>,
    onToggle: (String) -> Unit,
    onBookItem: (String) -> Unit,
    onOpenServices: () -> Unit
) {
    val doneCount = checklist.count { it.done }
    val pct = if (checklist.isEmpty()) 0 else (doneCount * 100) / checklist.size

    LazyColumn(modifier = Modifier.fillMaxWidth()) {
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                Text("Good evening, Prosen", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = SlateLight)
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                    Icon(trip.mode.icon(), contentDescription = null, tint = CoralDeep, modifier = Modifier.size(18.dp))
                    Text(
                        text = trip.title,
                        fontFamily = DisplaySerif,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Ink,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                    Icon(Icons.Filled.LocationOn, contentDescription = null, tint = Slate, modifier = Modifier.size(12.dp))
                    Text(trip.route, fontSize = 12.5.sp, color = Slate, modifier = Modifier.padding(start = 4.dp))
                }
            }
        }

        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                BreathingCountdown(hours = trip.hoursLeft, minutes = trip.minutesLeft)
            }
            Text(
                text = "$doneCount of ${checklist.size} ready · $pct%",
                fontSize = 12.5.sp,
                color = Slate,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }

        item {
            Text(
                text = "BEFORE YOU LEAVE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Ink,
                letterSpacing = 0.2.sp,
                modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 10.dp)
            )
        }

        items(checklist, key = { it.id }) { item ->
            ChecklistRow(
                item = item,
                onToggle = { onToggle(item.id) },
                onBook = { item.serviceId?.let { onBookItem(it) } },
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.5.dp)
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.5.dp, SlateLight, RoundedCornerShape(14.dp))
                    .clickable { onOpenServices() }
                    .padding(vertical = 13.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, tint = Slate, modifier = Modifier.size(16.dp))
                Text(
                    "Add a service to this trip",
                    color = Slate,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.5.sp,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Ink)
                    .padding(18.dp)
            ) {
                Text("FEELING UNCERTAIN?", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Paper.copy(alpha = 0.75f))
                Text(
                    "Everything above is confirmed and tracked. There's nothing left for you to hold in your head.",
                    fontSize = 14.sp,
                    color = Paper,
                    modifier = Modifier.padding(top = 6.dp, bottom = 12.dp)
                )
                Row {
                    PillTag("Ticket ✓")
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.width(8.dp))
                    PillTag("Weather: 27°C, clear")
                }
            }
        }
    }
}

@Composable
private fun PillTag(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White.copy(alpha = 0.12f))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text, color = Paper, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ChecklistRow(
    item: ChecklistItem,
    onToggle: () -> Unit,
    onBook: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, LineColor, RoundedCornerShape(14.dp))
            .background(Cream)
            .clickable { onToggle() }
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(if (item.done) Sage else Color.Transparent)
                .border(2.dp, if (item.done) SageDeep else LineColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (item.done) {
                Icon(Icons.Filled.Check, contentDescription = "Done", tint = Color.White, modifier = Modifier.size(14.dp))
            }
        }
        Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
            Text(
                text = item.label,
                fontSize = 14.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = Ink,
                textDecoration = if (item.done) TextDecoration.LineThrough else TextDecoration.None
            )
            if (item.sub.isNotBlank()) {
                Text(item.sub, fontSize = 12.sp, color = SlateLight, modifier = Modifier.padding(top = 1.dp))
            }
        }
        if (item.bookable && !item.done) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CoralPale)
                    .clickable { onBook() }
                    .padding(horizontal = 9.dp, vertical = 4.dp)
            ) {
                Text("Book", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Coral)
            }
        }
    }
}

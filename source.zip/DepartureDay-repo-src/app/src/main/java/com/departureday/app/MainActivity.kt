package com.departureday.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.departureday.app.ui.DepartureDayApp
import com.departureday.app.ui.theme.DepartureDayTheme
import com.departureday.app.ui.theme.Paper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DepartureDayTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Paper
                ) {
                    DepartureDayApp()
                }
            }
        }
    }
}

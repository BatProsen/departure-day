package com.departureday.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.departureday.app.ui.theme.Cream
import com.departureday.app.ui.theme.Coral
import com.departureday.app.ui.theme.LineColor
import com.departureday.app.ui.theme.SlateLight

enum class AppTab(val route: String, val label: String, val icon: ImageVector) {
    HOME("home", "Trip", Icons.Filled.Home),
    SERVICES("services", "Services", Icons.Filled.AutoAwesome),
    CALM("calm", "Calm", Icons.Filled.Air),
    PROFILE("profile", "You", Icons.Filled.Person)
}

@Composable
fun BottomNav(active: AppTab, onChange: (AppTab) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Cream)
            .border(width = 1.dp, color = LineColor)
            .wrapContentHeight()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp)
        ) {
            AppTab.values().forEach { tab ->
                val isActive = tab == active
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onChange(tab) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = tab.label,
                        tint = if (isActive) Coral else SlateLight,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Text(
                        text = tab.label,
                        fontSize = 10.5.sp,
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                        color = if (isActive) Coral else SlateLight
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
    }
}

package com.departureday.app.ui.screens

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.departureday.app.ui.theme.*
import kotlinx.coroutines.delay

private val breathPhases = listOf("Breathe in" to 150.dp, "Hold" to 120.dp, "Breathe out" to 90.dp, "Hold" to 120.dp)

@Composable
fun CalmScreen() {
    var phaseIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(4000)
            phaseIndex = (phaseIndex + 1) % breathPhases.size
        }
    }

    val (label, targetSize) = breathPhases[phaseIndex]
    val animatedSize by animateDpAsState(
        targetValue = targetSize,
        animationSpec = tween(durationMillis = 3600),
        label = "breathSize"
    )

    LazyColumn(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Text(
                "Take a moment",
                fontFamily = DisplaySerif,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = Ink,
                modifier = Modifier.padding(top = 18.dp, bottom = 4.dp)
            )
            Text(
                "A short box-breathing exercise — 4 seconds each phase.",
                fontSize = 13.sp,
                color = Slate,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 28.dp)
            )
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 26.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .clip(CircleShape)
                        .background(Sage.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(animatedSize)
                            .clip(CircleShape)
                            .background(SageDeep),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, color = Cream, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        item {
            Text(
                "WHILE YOU WAIT",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Ink,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            )
        }

        val tips = listOf(
            "Your ticket and ID are already in one place — check the Trip tab.",
            "Most delays at this station run under 15 minutes on weekday mornings.",
            "It's normal to recheck your bag more than once. That doesn't mean something's wrong."
        )

        items(tips) { tip ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 9.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Cream)
                    .border(1.dp, LineColor, RoundedCornerShape(12.dp))
                    .padding(horizontal = 13.dp, vertical = 11.dp)
            ) {
                Text(tip, fontSize = 13.sp, color = Slate)
            }
        }

        item { Box(modifier = Modifier.padding(bottom = 16.dp)) }
    }
}

package com.departureday.app.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.ui.graphics.vector.ImageVector

enum class TravelMode { TRAIN, FLIGHT, BUS }

fun TravelMode.icon(): ImageVector = when (this) {
    TravelMode.TRAIN -> Icons.Filled.Train
    TravelMode.FLIGHT -> Icons.Filled.Flight
    TravelMode.BUS -> Icons.Filled.DirectionsBus
}

data class Trip(
    val id: String,
    val title: String,
    val route: String,
    val mode: TravelMode,
    val departureLabel: String,
    val hoursLeft: Int,
    val minutesLeft: Int
)

/**
 * A bookable service offering, e.g. "Packing assistance".
 * `basePrice` is in INR (whole rupees) for the mock payment flow.
 */
data class ServiceOffering(
    val id: String,
    val name: String,
    val description: String,
    val icon: ImageVector,
    val durationLabel: String,
    val basePrice: Int
)

object ServiceCatalog {
    val all = listOf(
        ServiceOffering(
            id = "packing",
            name = "Packing assistance",
            description = "Someone comes home and helps pack — especially useful for elderly or first-time travellers.",
            icon = Icons.Filled.Luggage,
            durationLabel = "45–60 min",
            basePrice = 399
        ),
        ServiceOffering(
            id = "cab",
            name = "Cab, timed backward",
            description = "We work out your pickup time from departure, with buffer for traffic.",
            icon = Icons.Filled.DirectionsCar,
            durationLabel = "Booked in advance",
            basePrice = 549
        ),
        ServiceOffering(
            id = "escort",
            name = "Station / airport escort",
            description = "Wheelchair, luggage and navigation help from entrance to seat.",
            icon = Icons.Filled.VerifiedUser,
            durationLabel = "Through departure",
            basePrice = 699
        ),
        ServiceOffering(
            id = "companion",
            name = "Travel companion",
            description = "Someone accompanies an elderly or unwell relative for the whole journey.",
            icon = Icons.Filled.Security,
            durationLabel = "Full journey",
            basePrice = 1499
        ),
        ServiceOffering(
            id = "doctor",
            name = "Doctor-visit bundle",
            description = "Appointment reminder, cab and companion, bundled as one booking.",
            icon = Icons.Filled.LocalHospital,
            durationLabel = "Round trip",
            basePrice = 899
        )
    )
}

enum class PaymentMethod { UPI, CARD }

enum class BookingStatus { PENDING_PAYMENT, CONFIRMED }

data class Booking(
    val id: String,
    val service: ServiceOffering,
    val tripId: String,
    val note: String,
    val paymentMethod: PaymentMethod,
    val amountPaid: Int,
    val status: BookingStatus,
    val bookedAtLabel: String,
    val referenceCode: String
)

data class ChecklistItem(
    val id: String,
    val label: String,
    val sub: String,
    val done: Boolean,
    val bookable: Boolean = false,
    val serviceId: String? = null
)

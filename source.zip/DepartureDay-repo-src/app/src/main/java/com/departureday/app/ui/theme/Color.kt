package com.departureday.app.ui.theme

import androidx.compose.ui.graphics.Color

// Core palette — kept consistent with the original HTML/React prototype
val Paper = Color(0xFFFAF7F2)
val PaperDeep = Color(0xFFF1ECE2)
val Cream = Color(0xFFFFFDF9)
val Ink = Color(0xFF1F3A3D)
val InkSoft = Color(0xFF3C5558)
val Slate = Color(0xFF5B5A52)
val SlateLight = Color(0xFF8C8A7E)
val Coral = Color(0xFFE8825A)
val CoralDeep = Color(0xFFCE6A45)
val CoralPale = Color(0xFFFCEDE5)
val Sage = Color(0xFF8FA888)
val SageDeep = Color(0xFF6F8A6A)
val LineColor = Color(0xFFE4DFD2)
val DarkBg = Color(0xFF0F1E1F)
